# EV Battery Recycling Improvement App

A Streamlit web app for facility-specific EV battery recycling throughput, material-flow reconciliation, process-stage performance, electricity-related emissions, operating-cost screening, and conditional improvement recommendations.

## Run locally in VS Code

1. Extract the ZIP into a folder.
2. Open that folder in VS Code (`File` → `Open Folder`).
3. Open **Terminal → New Terminal** and confirm the terminal is in the folder containing `app.py` and `requirements.txt`.
4. Create/activate a virtual environment if desired, then install dependencies:

   ```powershell
   python -m pip install -r requirements.txt
   ```

5. Start the app:

   ```powershell
   python -m streamlit run app.py
   ```

6. Streamlit prints a local URL (usually `http://localhost:8501`). Open it in your browser.

## Important scope and assumptions

- No demo scenario or sample facility data is preloaded. Inputs start at zero/blank to avoid representing assumed data as measured data.
- The current carbon module includes **purchased electricity only**, adjusted for the entered renewable share. Diesel and LPG inputs were removed because they are not intrinsic to every recycling process. If a facility actually uses on-site fuels, add them only with facility records and a documented boundary.
- Transport, upstream energy emissions, chemical/reagent production, wastewater, residue treatment, capital equipment and avoided-material credits are excluded. This is not a full life-cycle assessment or a verified GHG inventory.
- The grid emission factor is editable and should be verified for the appropriate source and reporting year before formal reporting.
- Improvement recommendations are conditional on entered values. Cost ranges and savings percentages are rough screening assumptions, not vendor quotations or guaranteed savings. Confirm them with sub-metering, a plant trial, technical review and supplier quotations. Where the inputs do not support a defensible carbon estimate, the app does not claim one.
- The mass-balance check is an optional reconciliation tool, not a mandatory overview chart. A non-zero gap can reflect missing streams, inventory changes, moisture differences or measurement issues; it is not automatically a process loss.
- The Gemba board starts empty and is intended for actual observations recorded by the user.

## Main sections

- **Overview:** facility KPIs and optional mass-balance reconciliation.
- **Material recovery:** reported recovered output and residue split.
- **Process performance:** separate-shade stage efficiency chart and diagnostics.
- **Carbon footprint:** one electricity-related emissions chart and calculation boundary.
- **Improvement planner:** conditional practical actions, estimated cost/carbon comparisons where quantifiable, and CSV export.
- **Gemba board:** add observations and track status/priority.
- **Data & report:** CSV and TXT exports.
