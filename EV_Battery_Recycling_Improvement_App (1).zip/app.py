import math
from datetime import date
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

st.set_page_config(page_title="EV Battery Recycling Improvement App", page_icon="♻️", layout="wide")

st.markdown("""
<style>
.block-container{max-width:1500px;padding-top:1.2rem;padding-bottom:2rem}
.hero{padding:1.5rem 1.8rem;border-radius:20px;margin:.2rem 0 1rem;background:linear-gradient(115deg,#092f2a,#087f68 60%,#79c99b);color:white}
.hero h1{font-size:2.1rem;margin:.3rem 0 .45rem;color:white}.hero p{font-size:1rem;margin:0;color:#e4fff1}
div[data-testid="stMetric"]{background:rgba(21,150,105,.07);border:1px solid rgba(21,150,105,.18);padding:13px 15px;border-radius:14px;min-height:105px}
.stTabs [data-baseweb="tab-list"]{gap:8px}.stTabs [data-baseweb="tab"]{border-radius:10px 10px 0 0;padding:10px 13px}
</style>
""", unsafe_allow_html=True)
st.markdown('<div class="hero"><div style="font-size:.75rem;letter-spacing:.15rem;font-weight:750;color:#b7f4d2">CIRCULAR ECONOMY • RECYCLING OPERATIONS • CARBON & COST</div><h1>♻️ EV Battery Recycling Improvement App</h1><p>Enter facility data, understand material and energy performance, and compare practical process-improvement options.</p></div>', unsafe_allow_html=True)
st.caption("Scope: on-site recycling operations only. Transport is excluded. No demo scenario is preloaded; enter facility data in the sidebar. Outputs are screening estimates, not a verified GHG inventory or engineering quotation.")

# Inputs: start empty/zero so no illustrative values are mistaken for facility facts.
st.sidebar.title("Facility data")
st.sidebar.caption("Enter one consistent reporting period, ideally 12 months. Use measured records wherever possible.")
facility = st.sidebar.text_input("Facility name (optional)", "")
with st.sidebar.expander("1 · Throughput & mass flow", expanded=True):
    input_t = st.number_input("Battery input (tonnes/year)", min_value=0.0, max_value=1_000_000.0, value=0.0, step=100.0)
    capacity_t = st.number_input("Rated capacity (tonnes/year)", min_value=0.0, max_value=1_000_000.0, value=0.0, step=100.0)
    batteries_n = st.number_input("Batteries processed (units/year, optional)", min_value=0, max_value=100_000_000, value=0, step=100)
    recovered_t = st.number_input("Recovered material output (tonnes/year)", min_value=0.0, max_value=1_000_000.0, value=0.0, step=10.0)
    residue_t = st.number_input("Residues / non-recovered output (tonnes/year)", min_value=0.0, max_value=1_000_000.0, value=0.0, step=10.0)
with st.sidebar.expander("2 · Electricity & carbon", expanded=True):
    kwh_total = st.number_input("Electricity used by recycling operations (kWh/year)", min_value=0.0, max_value=1_000_000_000.0, value=0.0, step=10000.0)
    renewable_pct = st.number_input("Renewable electricity share (%)", min_value=0.0, max_value=100.0, value=0.0, step=5.0)
    grid_ef = st.number_input("Grid emission factor (kg CO₂e/kWh)", min_value=0.0, max_value=3.0, value=0.675, step=0.005, format="%.3f", help="Verify the factor and reporting year against an official source before formal use.")
    electricity_rate = st.number_input("Electricity tariff (₹/kWh)", min_value=0.0, max_value=1000.0, value=0.0, step=0.5)
with st.sidebar.expander("3 · Process performance", expanded=True):
    st.caption("Only include stages performed at this facility. Values should be calculated from each stage's measured good output ÷ stage input. They are not cumulative yields.")
    stages = ["Discharge & dismantling", "Shredding & separation", "Black-mass preparation"]
    stage_eff = {}
    for stage in stages:
        stage_eff[stage] = st.number_input(f"{stage} efficiency (%)", min_value=0.0, max_value=100.0, value=0.0, step=1.0, key=f"eff_{stage}")
with st.sidebar.expander("4 · Operating costs", expanded=True):
    residue_cost = st.number_input("Residue handling cost (₹/tonne residue)", min_value=0.0, max_value=1_000_000.0, value=0.0, step=100.0)
    labour_maintenance = st.number_input("Labour & maintenance (₹/year, optional)", min_value=0.0, max_value=1_000_000_000.0, value=0.0, step=10000.0)
    other_cost = st.number_input("Other relevant operating costs (₹/year, optional)", min_value=0.0, max_value=1_000_000_000.0, value=0.0, step=10000.0)
    evidence = st.text_area("Data source / evidence note", "", placeholder="e.g., electricity bills Apr–Mar; weighbridge records; residue invoices")

# Core calculations
nonrenewable_share = 1 - renewable_pct / 100
electricity_emissions_t = kwh_total * nonrenewable_share * grid_ef / 1000
emissions_t = electricity_emissions_t
carbon_intensity = emissions_t * 1000 / input_t if input_t > 0 else 0
electricity_cost = kwh_total * electricity_rate
annual_cost_known = electricity_cost + residue_t * residue_cost + labour_maintenance + other_cost
cost_per_input = annual_cost_known / input_t if input_t > 0 else 0
cost_per_recovered = annual_cost_known / recovered_t if recovered_t > 0 else 0
utilisation = input_t / capacity_t * 100 if capacity_t > 0 else 0
recovery_rate = recovered_t / input_t * 100 if input_t > 0 else 0
mass_gap = input_t - recovered_t - residue_t
kwh_per_t = kwh_total / input_t if input_t > 0 else 0
residue_rate = residue_t / input_t * 100 if input_t > 0 else 0

# Conditional, rule-based options. Quantified benefits only where the input data supports them.
options = []
def add_option(name, trigger, action, capex_low, capex_high, kwh_saving_pct=0, residue_saving_pct=0, confidence="Screening estimate", prerequisites=""):
    if trigger:
        saved_kwh = kwh_total * kwh_saving_pct / 100
        saved_residue_t = residue_t * residue_saving_pct / 100
        annual_saving = saved_kwh * electricity_rate + saved_residue_t * residue_cost
        carbon_saving = saved_kwh * nonrenewable_share * grid_ef / 1000
        options.append({
            "Improvement": name, "Why it is suggested": trigger if isinstance(trigger, str) else "",
            "Practical action": action, "Estimated annual electricity saving (kWh)": saved_kwh,
            "Estimated annual residue reduction (t)": saved_residue_t,
            "Estimated annual cost saving (₹)": annual_saving,
            "Estimated annual carbon reduction (t CO₂e)": carbon_saving,
            "Indicative one-time cost — low (₹)": capex_low,
            "Indicative one-time cost — high (₹)": capex_high,
            "Simple payback — low-cost case (years)": capex_low / annual_saving if annual_saving > 0 else None,
            "Simple payback — high-cost case (years)": capex_high / annual_saving if annual_saving > 0 else None,
            "Evidence needed": prerequisites,
            "Confidence": confidence
        })

if input_t > 0 and kwh_total > 0:
    if kwh_per_t >= 250:
        add_option("Audit high electricity intensity", f"Current electricity intensity is {kwh_per_t:,.0f} kWh per tonne; this is a screening trigger, not a universal industry benchmark.", "Sub-meter shredder, separator and dust-collection loads for 2–4 weeks; compare kWh/tonne by batch and shift; stop idle-running equipment and correct abnormal loads. Use a 5–10% trial saving only after a measured baseline.", 50000, 250000, 7.5, prerequisites="Sub-meter or temporary logger; shift/batch throughput records; equipment run-hours.")
    else:
        add_option("Batch scheduling and idle shutdown", f"Electricity intensity is {kwh_per_t:,.0f} kWh/tonne; check whether machines run while waiting for feed or between batches.", "Align battery preparation with shredder/separator availability; add a written shutdown checklist and safe restart sequence; log idle hours and kWh per batch. Model a conservative 3–6% electricity saving only if idle load is confirmed.", 10000, 80000, 4.5, prerequisites="Operator observations, machine run-hours, idle-load measurements.")
    if renewable_pct < 100:
        add_option("Reduce avoidable motor and dust-collection load", "Electricity is a measured cost/emissions source and some process equipment may be running inefficiently.", "Inspect belt tension, bearings, clogged filters and duct leaks; clean dust-collection filters; check motor loading and align preventive-maintenance intervals with OEM guidance. Implement variable-speed control only after a load study confirms suitability.", 30000, 300000, 5, prerequisites="Maintenance logs, motor nameplates, filter pressure-drop and run-hour records.")
if input_t > 0 and residue_t > 0 and residue_cost > 0:
    if residue_rate >= 25:
        add_option("Characterise and segregate residue streams", f"Residues are {residue_rate:.1f}% of input, so the waste stream deserves a measured review; this percentage alone does not prove poor performance.", "Weigh residues separately by stream; sample composition; separate recoverable metal-rich fractions from true rejects; obtain authorised downstream recovery/disposal quotes. Do not return material to process unless safety and quality checks permit it.", 25000, 150000, residue_saving_pct=10, prerequisites="Stream-wise weights, representative assays, authorised receiver quotes.", confidence="Cost saving is a 10% handling-cost scenario; carbon benefit not quantified without destination-specific factors.")
    else:
        add_option("Improve residue weighing and destination control", f"Residue handling currently costs ₹{residue_t*residue_cost:,.0f}/year; validate weights and destination charges before choosing a process change.", "Use labelled containers and a standard weigh ticket for each residue stream; reconcile dispatched weights to invoices; compare authorised receiver terms and contamination penalties. This is a cost-control action, not an assumed recovery improvement.", 10000, 60000, residue_saving_pct=5, prerequisites="Weigh tickets, invoices, manifests and receiver acceptance criteria.", confidence="Illustrative 5% handling-cost scenario; validate against invoices.")
if input_t > 0 and recovered_t >= 0 and residue_t >= 0 and mass_gap < -max(1.0, input_t*0.02):
    add_option("Reconcile mass balance before investing", f"Reported outputs exceed input by {abs(mass_gap):,.1f} tonnes/year; the data do not reconcile within a 2% screening tolerance.", "Check reporting period, stock changes, moisture basis, added process materials, double-counted black mass/metal outputs and scale calibration. Do not treat the apparent recovery rate as a process improvement target until corrected.", 0, 20000, prerequisites="Weighbridge calibration, opening/closing inventory, moisture basis, output definitions.", confidence="Diagnostic action; no carbon/cost saving claimed until data are reconciled.")
if input_t > 0 and recovered_t + residue_t < input_t - max(1.0, input_t*0.02):
    add_option("Trace unaccounted material streams", f"The mass balance leaves {mass_gap:,.1f} tonnes/year unaccounted for; this may be missing records, inventory, moisture or process loss.", "Reconcile each batch from input to recovered products, residues, work-in-progress and stock changes; weigh containers at each hand-off. Identify the largest unexplained stream before changing equipment settings.", 0, 30000, prerequisites="Batch-level input/output weights and opening/closing inventory.", confidence="Diagnostic action; no carbon/cost saving claimed until measured.")
for stage, val in stage_eff.items():
    if val > 0 and val < 85 and input_t > 0:
        add_option(f"Run a controlled trial for {stage.lower()}", f"Entered {stage.lower()} efficiency is {val:.0f}%; verify the measurement basis and identify the stage's actual loss stream.", f"Run a short controlled trial: record stage input, good output, rejects, moisture and downtime by batch; change one operating variable at a time and compare yield/quality before adopting it. Do not infer a carbon saving until energy and output changes are measured.", 15000, 100000, prerequisites="Stage-level mass records, product quality, reject composition and run time.", confidence="Trial recommendation; carbon and cost impact not quantified without plant data.")

# Tabs
overview, material_tab, process_tab, carbon_tab, improve_tab, gemba_tab, report_tab = st.tabs(["🌱 Overview", "🔋 Material recovery", "⚙️ Process performance", "🌍 Carbon footprint", "💡 Improvement planner", "👷 Gemba board", "📊 Data & report"])

with overview:
    st.subheader("Facility performance at a glance")
    if input_t == 0:
        st.info("Start by entering annual battery input, recovered output, residues and electricity in the sidebar. The app does not load demo data.")
    a,b,c,d = st.columns(4)
    a.metric("Battery input", f"{input_t:,.1f} t/year")
    b.metric("Recovered output", f"{recovered_t:,.1f} t/year")
    c.metric("Recovered-output rate", f"{recovery_rate:,.1f}%" if input_t else "—")
    d.metric("Electricity-only footprint", f"{emissions_t:,.2f} t CO₂e/year")
    a,b,c,d = st.columns(4)
    a.metric("Capacity utilisation", f"{utilisation:,.1f}%" if capacity_t else "—")
    b.metric("Electricity intensity", f"{kwh_per_t:,.1f} kWh/t" if input_t else "—")
    c.metric("Annual known operating cost", f"₹{annual_cost_known:,.0f}")
    d.metric("Carbon intensity", f"{carbon_intensity:,.1f} kg CO₂e/t" if input_t else "—")
    with st.expander("Annual mass-balance check (reconciliation tool)", expanded=False):
        st.caption("Not mandatory for every overview screen, but useful for checking that input, recovered output and residues reconcile. Use the same reporting period and consistent moisture/inventory basis.")
        if input_t > 0:
            st.write(f"**Input − recovered output − residues = {input_t:,.1f} − {recovered_t:,.1f} − {residue_t:,.1f} = {mass_gap:,.1f} tonnes/year**")
            if abs(mass_gap) <= max(1.0,input_t*0.02): st.success(f"Within the 2% screening tolerance (gap: {mass_gap:,.1f} t/year). Confirm records before reporting.")
            else: st.warning(f"Needs reconciliation: gap = {mass_gap:,.1f} t/year. Check missing streams, stock changes, moisture basis and weighing records.")
        else:
            st.info("Enter annual battery input to calculate the mass-balance gap.")
    if capacity_t > 0 and utilisation > 100: st.warning("Input exceeds rated capacity. Check units and reporting period.")
    st.caption(f"Facility: {facility or 'Not specified'} · Data evidence: {evidence or 'Not supplied'}")

with material_tab:
    st.subheader("Material recovery")
    if input_t <= 0: st.info("Enter battery input and recovered output in the sidebar to calculate material recovery.")
    else:
        c1,c2,c3=st.columns(3); c1.metric("Input",f"{input_t:,.1f} t/y"); c2.metric("Recovered output",f"{recovered_t:,.1f} t/y"); c3.metric("Recovered-output rate",f"{recovery_rate:,.1f}%")
        st.caption("This is total recovered output divided by battery input. It is not the same as recovery of individual elements such as lithium, nickel or cobalt. Avoid double-counting black mass and metals recovered from that same black mass.")
        df=pd.DataFrame({"Material stream":["Recovered output","Residues / non-recovered","Unaccounted gap"],"Tonnes/year":[recovered_t,residue_t,mass_gap]})
        fig=px.bar(df,x="Material stream",y="Tonnes/year",color="Material stream",color_discrete_sequence=["#147d64","#79b6a3","#d97706"],text_auto=".1f",title="Reported material streams")
        fig.update_layout(showlegend=False); st.plotly_chart(fig,use_container_width=True)
        st.dataframe(df,use_container_width=True,hide_index=True)

with process_tab:
    st.subheader("Process efficiency by recycling stage")
    st.caption("Stage values are facility-entered. Blank/zero means not provided, not necessarily 0% efficiency.")
    active=[(s,v) for s,v in stage_eff.items() if v>0]
    if not active: st.info("Enter measured efficiency for at least one applicable process stage in the sidebar.")
    else:
        stage_df=pd.DataFrame(active,columns=["Process stage","Process efficiency (%)"])
        palette=["#0b6e5b","#168f78","#45a98e","#80c7ad","#b3dfcc"]
        fig=px.bar(stage_df,x="Process efficiency (%)",y="Process stage",orientation="h",color="Process stage",color_discrete_sequence=palette,text=stage_df["Process efficiency (%)"].map(lambda x:f"{x:.0f}%"),title="Stage performance scorecard")
        fig.update_layout(xaxis_range=[0,110],xaxis_title="Efficiency (%)",yaxis_title="",showlegend=False,margin=dict(l=10,r=25,t=55,b=10),height=350)
        st.plotly_chart(fig,use_container_width=True)
        st.dataframe(stage_df,use_container_width=True,hide_index=True)
    st.info("For a real facility, calculate each stage as good output mass ÷ that stage's input mass × 100. Compare only stages with compatible measurement definitions; this is not a universal benchmark.")

with carbon_tab:
    st.subheader("Operational carbon footprint — electricity boundary")
    st.write("This version includes purchased electricity used by recycling operations only. Diesel and LPG fields have been removed because they are not inherent to every recycling process; if a facility actually burns fuel on-site, that source should be added only when supported by its records and clearly included in the boundary.")
    a,b,c=st.columns(3); a.metric("Electricity emissions",f"{electricity_emissions_t:,.2f} t CO₂e/year"); b.metric("Carbon intensity",f"{carbon_intensity:,.1f} kg CO₂e/t" if input_t else "—"); c.metric("Electricity consumption",f"{kwh_total:,.0f} kWh/year")
    source_df=pd.DataFrame({"Emission source":["Grid electricity after renewable share"],"Activity (kWh/year)":[kwh_total*nonrenewable_share],"Emissions (t CO₂e/year)":[electricity_emissions_t]})
    fig=px.bar(source_df,x="Emission source",y="Emissions (t CO₂e/year)",text=source_df["Emissions (t CO₂e/year)"].map(lambda x:f"{x:,.2f} t"),title="Annual electricity-related emissions",color_discrete_sequence=["#147d64"])
    fig.update_layout(showlegend=False,yaxis_title="tonnes CO₂e/year",xaxis_title="",margin=dict(l=10,r=10,t=55,b=10)); st.plotly_chart(fig,use_container_width=True)
    st.latex(r"E_{electricity}=kWh\times(1-renewable\ share)\times EF_{grid}")
    st.warning(f"Screening estimate only. Grid factor entered: {grid_ef:.3f} kg CO₂e/kWh. Verify the factor and year before formal reporting. This is not a full lifecycle assessment: transport, upstream energy supply, chemical/reagent production, waste treatment, process emissions and avoided-material credits are excluded.")

with improve_tab:
    st.subheader("Improvement planner: practical actions matched to your inputs")
    st.write("Recommendations appear only when the entered data triggers a relevant diagnostic. The app does not use sliders to invent improvement percentages. Savings and implementation costs are indicative screening ranges that must be confirmed with a plant trial, vendor quote or audit.")
    if input_t <= 0:
        st.info("Enter facility input, electricity use and/or residue data to generate relevant improvement options. No generic preloaded options are shown.")
    elif not options:
        st.success("No rule-based recommendation was triggered by the values entered. This does not prove the process is optimal; review measured stage data and plant-specific constraints.")
    else:
        result_df=pd.DataFrame(options)
        st.markdown("#### Options identified from the current facility data")
        for i,row in result_df.iterrows():
            with st.expander(f"{i+1}. {row['Improvement']}", expanded=(i==0)):
                st.markdown(f"**Why this appeared:** {row['Why it is suggested']}")
                st.write(row["Practical action"])
                st.write(f"**Indicative one-time cost:** ₹{row['Indicative one-time cost — low (₹)']:,.0f}–₹{row['Indicative one-time cost — high (₹)']:,.0f}")
                st.write(f"**Estimated annual cost saving:** ₹{row['Estimated annual cost saving (₹)']:,.0f}")
                st.write(f"**Estimated annual carbon reduction:** {row['Estimated annual carbon reduction (t CO₂e)']:,.2f} t CO₂e")
                st.caption(f"Evidence needed: {row['Evidence needed']} · Confidence: {row['Confidence']}")
        quantified=result_df[(result_df["Estimated annual cost saving (₹)"]>0) | (result_df["Estimated annual carbon reduction (t CO₂e)"]>0)].copy()
        if not quantified.empty:
            st.markdown("#### Compare quantified options")
            left,right=st.columns(2)
            with left:
                plot_df=quantified.sort_values("Estimated annual carbon reduction (t CO₂e)")
                fig=px.bar(plot_df,x="Estimated annual carbon reduction (t CO₂e)",y="Improvement",orientation="h",color="Improvement",color_discrete_sequence=["#0b6e5b","#168f78","#45a98e","#80c7ad"],text=plot_df["Estimated annual carbon reduction (t CO₂e)"].map(lambda x:f"{x:.2f} t"),title="Estimated annual carbon reduction")
                fig.update_layout(showlegend=False,margin=dict(l=5,r=15,t=55,b=10)); st.plotly_chart(fig,use_container_width=True)
            with right:
                plot_df=quantified.sort_values("Estimated annual cost saving (₹)")
                fig=px.bar(plot_df,x="Estimated annual cost saving (₹)",y="Improvement",orientation="h",color="Improvement",color_discrete_sequence=["#0b6e5b","#168f78","#45a98e","#80c7ad"],text=plot_df["Estimated annual cost saving (₹)"].map(lambda x:f"₹{x:,.0f}"),title="Estimated annual operating-cost saving")
                fig.update_layout(showlegend=False,margin=dict(l=5,r=15,t=55,b=10)); st.plotly_chart(fig,use_container_width=True)
            st.caption("Cost savings use only electricity and residue-handling costs affected by each option. Carbon reductions are quantified only for electricity savings; residue-related carbon impact is deliberately left unquantified without a destination-specific emissions factor. Capital cost is a broad placeholder, not a supplier quote.")
            st.dataframe(quantified[["Improvement","Estimated annual cost saving (₹)","Estimated annual carbon reduction (t CO₂e)","Indicative one-time cost — low (₹)","Indicative one-time cost — high (₹)","Simple payback — low-cost case (years)","Simple payback — high-cost case (years)","Confidence"]],use_container_width=True,hide_index=True)
        st.download_button("Download improvement comparison (CSV)",result_df.to_csv(index=False).encode("utf-8"),"ev_battery_improvement_comparison.csv","text/csv")
        if not quantified.empty:
            best_cost=quantified.sort_values("Estimated annual cost saving (₹)",ascending=False).iloc[0]
            best_carbon=quantified.sort_values("Estimated annual carbon reduction (t CO₂e)",ascending=False).iloc[0]
            st.markdown("#### Decision support")
            x,y=st.columns(2)
            x.success(f"Highest estimated annual cost saving: **{best_cost['Improvement']}** (₹{best_cost['Estimated annual cost saving (₹)']:,.0f}/year).")
            y.success(f"Highest estimated annual carbon reduction: **{best_carbon['Improvement']}** ({best_carbon['Estimated annual carbon reduction (t CO₂e)']:.2f} t CO₂e/year).")
            st.caption("The best choice may differ by budget, production constraints, safety, product quality and implementation cost. Confirm feasibility before selecting an option.")

with gemba_tab:
    st.subheader("Gemba board — record real observations")
    st.write("Add observations from an actual facility walk. The table starts empty so it does not imply that any specific issues have been observed.")
    blank=pd.DataFrame(columns=["Process stage","Observation / evidence","Priority","Status","Countermeasure","Owner","Due date"])
    edited=st.data_editor(blank,use_container_width=True,hide_index=True,num_rows="dynamic",column_config={
        "Priority":st.column_config.SelectboxColumn(options=["Critical","High","Medium","Low"]),
        "Status":st.column_config.SelectboxColumn(options=["Not checked","Action required","In progress","Closed","Not applicable"]),
        "Due date":st.column_config.TextColumn(help="Enter date as YYYY-MM-DD")},key="gemba_editor")
    if not edited.empty:
        left,right=st.columns(2)
        with left:
            status_counts=edited["Status"].fillna("Not checked").value_counts().rename_axis("Status").reset_index(name="Count")
            fig=px.bar(status_counts,x="Status",y="Count",color="Status",color_discrete_sequence=["#0b6e5b","#168f78","#45a98e","#80c7ad"]); fig.update_layout(showlegend=False,title="Observations by status"); st.plotly_chart(fig,use_container_width=True)
        with right:
            priority_counts=edited["Priority"].fillna("Medium").value_counts().rename_axis("Priority").reset_index(name="Count")
            fig=px.bar(priority_counts,x="Priority",y="Count",color="Priority",color_discrete_sequence=["#b91c1c","#d97706","#0b6e5b","#80c7ad"]); fig.update_layout(showlegend=False,title="Actions by priority"); st.plotly_chart(fig,use_container_width=True)
        st.download_button("Download Gemba observations (CSV)",edited.to_csv(index=False).encode("utf-8"),"ev_battery_gemba_observations.csv","text/csv")

with report_tab:
    st.subheader("Data & report")
    report_rows=[
        ("Facility",facility or "Not specified","name"),("Annual battery input",input_t,"tonnes/year"),("Rated capacity",capacity_t,"tonnes/year"),("Batteries processed",batteries_n,"units/year"),("Recovered output",recovered_t,"tonnes/year"),("Residues",residue_t,"tonnes/year"),("Mass balance gap",mass_gap,"tonnes/year"),("Capacity utilisation",utilisation,"%"),("Recovered-output rate",recovery_rate,"%"),("Electricity use",kwh_total,"kWh/year"),("Renewable share",renewable_pct,"%"),("Grid emission factor",grid_ef,"kg CO₂e/kWh"),("Electricity emissions",emissions_t,"tonnes CO₂e/year"),("Carbon intensity",carbon_intensity,"kg CO₂e/tonne input"),("Electricity cost",electricity_cost,"₹/year"),("Known operating cost total",annual_cost_known,"₹/year"),("Cost per input tonne",cost_per_input,"₹/tonne"),("Cost per recovered tonne",cost_per_recovered,"₹/tonne"),("Evidence note",evidence or "Not supplied","note")]
    report_df=pd.DataFrame(report_rows,columns=["Metric","Value","Unit"])
    st.dataframe(report_df,use_container_width=True,hide_index=True)
    st.download_button("Download facility data (CSV)",report_df.to_csv(index=False).encode("utf-8"),"ev_battery_facility_data.csv","text/csv")
    report=["EV BATTERY RECYCLING FACILITY SCREENING REPORT",f"Generated: {date.today().isoformat()}",f"Facility: {facility or 'Not specified'}",f"Evidence note: {evidence or 'Not supplied'}","","BOUNDARY","Included: purchased electricity used by recycling operations, adjusted for the entered renewable share.","Excluded: transport, on-site fuel combustion (not collected in this version), upstream energy emissions, chemical/reagent production, wastewater, waste treatment, capital goods and avoided-material credits.","This is a screening estimate, not a verified GHG inventory or complete life-cycle assessment.","","KEY VALUES"]
    report += [f"{r['Metric']}: {r['Value']} {r['Unit']}" for _,r in report_df.iterrows()]
    if options:
        report += ["","CONDITIONALLY SUGGESTED IMPROVEMENTS"]
        for o in options: report.append(f"{o['Improvement']}: annual cost saving estimate ₹{o['Estimated annual cost saving (₹)']:,.0f}; annual carbon reduction estimate {o['Estimated annual carbon reduction (t CO₂e)']:.2f} t; indicative one-time cost ₹{o['Indicative one-time cost — low (₹)']:,.0f}–₹{o['Indicative one-time cost — high (₹)']:,.0f}. {o['Practical action']} Evidence needed: {o['Evidence needed']}")
    st.download_button("Download report (TXT)","\n".join(report).encode("utf-8"),"ev_battery_recycling_report.txt","text/plain")
    st.caption("The app does not load demo inputs. Keep source records and verify all estimates before using results for formal reporting or investment decisions.")
